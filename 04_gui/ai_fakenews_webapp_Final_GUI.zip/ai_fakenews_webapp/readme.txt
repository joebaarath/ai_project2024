

Instructions

Setup:

1) Create a new virtual env environment:
python -m venv venv

2) Activate the environment
.\venv\Scripts\activate

3) Install requirements
pip install -r requirements.txt 

4) Run flask web app
python app.py




Usage to predict new stance:
1) Upload fake news csv (i.e. lemmatized_dataset_final_balanced_test.csv )

2) Click Submit Button

3) Get prediction csv file

